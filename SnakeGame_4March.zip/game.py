from turtle import Turtle, Screen
from snake import Snake
from target import Target

class Game:
    def __init__(self):
        self.screen = Screen()
        self.screen.setup(width=600, height=600)
        self.screen.bgcolor('black')
        self.screen.title("Snake Game")
        self.score = 0

        self.snake = Snake()
        self.target = Target()
        self.target.update()

        self.active_direction = None

        self.screen.listen()
        self.screen.onkey(self.set_direction_right, "Right")
        self.screen.onkey(self.set_direction_left, "Left")
        self.screen.onkey(self.set_direction_up, "Up")
        self.screen.onkey(self.set_direction_down, "Down")

        #set the active direction based on the key press and call the snake to move in that direction

        self.screen.exitonclick()

    def set_direction_right(self):
        self.active_direction = "Right"
        while self.active_direction == "Right":
            self.snake.move_right()
            self.evaluate_target()


    def set_direction_left(self):
        self.active_direction = "Left"
        while self.active_direction == "Left":
            self.snake.move_left()
            self.evaluate_target()

    def set_direction_up(self):
        self.active_direction = "Up"
        while self.active_direction == "Up":
            self.snake.move_up()
            self.evaluate_target()

    def set_direction_down(self):
        self.active_direction = "Down"
        while self.active_direction == "Down":
            self.snake.move_down()
            self.evaluate_target()

    def evaluate_target(self):
        if self.target.x == self.snake.head.x and self.target.y == self.snake.head.y:
            self.target.update()
            self.snake.add_segment()



