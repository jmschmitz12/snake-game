from game import Game

def main():
    """initialize the game"""
    game = Game()


if __name__ == "__main__":
    main()




