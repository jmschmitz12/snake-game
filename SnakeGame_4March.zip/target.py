from turtle import Turtle
import random

class Target:
    def __init__(self):
        self.target = Turtle("square")
        self.target.color("white")
        self.target.penup()

    def round_to_nearest_20(n):
        # Round n to the nearest multiple of 20
        return round(n / 20) * 20

    def update(self):
        self.x = round(random.randint(-300, 300)/20) * 20
        self.y = round(random.randint(-300, 300)/20) * 20

        self.target.hideturtle()
        self.target.setposition(self.x, self.y)
        self.target.showturtle()

        #print(f"Target position: {(self.x, self.y)}")







